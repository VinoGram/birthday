/birthday-website
|-- index.html             (Landing page)
|-- wish.html              (Page to make a wish)
|-- meal-catalog.html      (Meal selection page)
|-- /assets                (Folder for images and audio)
|   |-- happy_birthday_song.mp3
|   |-- meal1.jpg
|   |-- meal2.jpg
|   |-- meal3.jpg
|-- server.js              (Node.js server)
